import axios from 'axios';
import { useCallback, useEffect, useState } from 'react';
import { Outlet, useNavigate, useParams } from 'react-router-dom';
import './Form.css';

const Form = () => {
  const [query, setQuery] = useState('');
  const [searchedMovieList, setSearchedMovieList] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [movie, setMovie] = useState(null);
  const navigate = useNavigate();
  const { movieId } = useParams();

  const apiToken = process.env.REACT_APP_TMDB_API_TOKEN; // Use environment variable for security

  const handleSearch = useCallback(() => {
    if (!query) return;

    axios
      .get(
        `https://api.themoviedb.org/3/search/movie?query=${query}&include_adult=false&language=en-US&page=1`,
        {
          headers: {
            Accept: 'application/json',
            Authorization: `Bearer ${apiToken}`,
          },
        }
      )
      .then((response) => {
        setSearchedMovieList(response.data.results);
      })
      .catch((error) => console.error('Search error:', error));
  }, [query, apiToken]);

  const handleSelectMovie = (movie) => {
    setSelectedMovie(movie);
  };

  const handleSave = () => {
    const accessToken = localStorage.getItem('accessToken');
    if (!selectedMovie) {
      alert('Please search and select a movie.');
      return;
    }

    const data = {
      tmdbId: selectedMovie.id,
      title: selectedMovie.title,
      overview: selectedMovie.overview,
      popularity: selectedMovie.popularity,
      releaseDate: selectedMovie.release_date,
      voteAverage: selectedMovie.vote_average,
      backdropPath: `https://image.tmdb.org/t/p/original/${selectedMovie.backdrop_path}`,
      posterPath: `https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`,
      isFeatured: 0,
    };

    axios
      .post('/movies', data, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      .then(() => alert('Movie saved successfully!'))
      .catch((error) => console.error('Save error:', error));
  };

  const handleUpdate = () => {
    const accessToken = localStorage.getItem('accessToken');
    if (!movieId || !movie) return;

    axios
      .put(`/movies/${movieId}`, movie, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      .then(() => alert('Movie updated successfully!'))
      .catch((error) => console.error('Update error:', error));
  };

  const handleDelete = () => {
    const accessToken = localStorage.getItem('accessToken');
    if (!movieId) return;

    axios
      .delete(`/movies/${movieId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      })
      .then(() => {
        alert('Movie deleted successfully!');
        navigate('/main/movies');
      })
      .catch((error) => console.error('Delete error:', error));
  };

  useEffect(() => {
    if (movieId) {
      axios
        .get(`/movies/${movieId}`)
        .then((response) => {
          setMovie(response.data);
          const tempData = {
            id: response.data.tmdbId,
            original_title: response.data.title,
            overview: response.data.overview,
            popularity: response.data.popularity,
            poster_path: response.data.posterPath,
            release_date: response.data.releaseDate,
            vote_average: response.data.voteAverage,
          };
          setSelectedMovie(tempData);
        })
        .catch((error) => console.error('Fetch error:', error));
    }
  }, [movieId]);

  return (
    <>
      <h1>{movieId ? 'Edit Movie' : 'Create Movie'}</h1>

      {!movieId && (
        <>
          <div className="search-container">
            <label>Search Movie:</label>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            <button type="button" onClick={handleSearch}>
              Search
            </button>
            <div className="searched-movie">
              {searchedMovieList.map((movie) => (
                <p key={movie.id} onClick={() => handleSelectMovie(movie)}>
                  {movie.original_title}
                </p>
              ))}
            </div>
          </div>
          <hr />
        </>
      )}

      <div className="container">
        <form>
          {selectedMovie && (
            <img
              className="poster-image"
              src={`https://image.tmdb.org/t/p/original/${selectedMovie.poster_path}`}
              alt={selectedMovie.original_title}
            />
          )}
          <div className="field">
            <label>Title:</label>
            <input
              type="text"
              value={movie?.title || ''}
              onChange={(e) =>
                setMovie((prev) => ({ ...prev, title: e.target.value }))
              }
            />
          </div>
          <div className="field">
            <label>Overview:</label>
            <textarea
              rows={10}
              value={movie?.overview || ''}
              onChange={(e) =>
                setMovie((prev) => ({ ...prev, overview: e.target.value }))
              }
            />
          </div>
          <div className="field">
            <label>Popularity:</label>
            <input
              type="number"
              value={movie?.popularity || ''}
              onChange={(e) =>
                setMovie((prev) => ({ ...prev, popularity: e.target.value }))
              }
            />
          </div>
          <div className="field">
            <label>Release Date:</label>
            <input
              type="date"
              value={movie?.releaseDate || ''}
              onChange={(e) =>
                setMovie((prev) => ({ ...prev, releaseDate: e.target.value }))
              }
            />
          </div>
          <div className="field">
            <label>Vote Average:</label>
            <input
              type="number"
              step="0.1"
              value={movie?.voteAverage || ''}
              onChange={(e) =>
                setMovie((prev) => ({ ...prev, voteAverage: e.target.value }))
              }
            />
          </div>
          {movieId ? (
            <>
              <button type="button" onClick={handleUpdate}>
                Update
              </button>
              <button type="button" onClick={handleDelete}>
                Delete
              </button>
            </>
          ) : (
            <button type="button" onClick={handleSave}>
              Save
            </button>
          )}
        </form>
      </div>

      {movieId && movie && (
        <div>
          <hr />
          <nav>
            <ul className="tabs">
              <li onClick={() => navigate(`/main/movies/form/${movieId}/cast-and-crews`)}>
                Cast & Crews
              </li>
              <li onClick={() => navigate(`/main/movies/form/${movieId}/videos`)}>
                Videos
              </li>
              <li onClick={() => navigate(`/main/movies/form/${movieId}/photos`)}>
                Photos
              </li>
            </ul>
          </nav>
          <Outlet />
        </div>
      )}
    </>
  );
};

export default Form;
