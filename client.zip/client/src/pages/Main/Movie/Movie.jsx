import React from 'react';
import { useEffect } from 'react';
import { useMovieContext } from '../../../../context/MovieContext';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Movie.css';

function Movie() {
  const { movies, setMovies } = useMovieContext();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await axios.get('/movies');
        setMovies(response.data);
      } catch (error) {
        console.error('Failed to fetch movies:', error);
      }
    };

    fetchMovies();
  }, [setMovies]);

  const handleMovieClick = (movieId) => {
    navigate(`/view/${movieId}`);
  };

  if (!movies || movies.length === 0) {
    return <div className="loading">Loading Movies...</div>;
  }

  return (
    <div className="movie-container">
      <h1>Movie Collection</h1>
      
      <div className="movie-content">
        <section className="movie-grid">
          {movies.map((movie) => (
            <div 
              key={movie.id} 
              className="movie-card"
              onClick={() => handleMovieClick(movie.id)}
            >
              {(movie.poster_path || movie.backdrop_path) && (
                <img 
                  src={`https://image.tmdb.org/t/p/w500${movie.poster_path || movie.backdrop_path}`} 
                  alt={movie.title} 
                  className="movie-poster"
                />
              )}
              <div className="movie-info">
                <h2>{movie.title}</h2>
                <p>{movie.overview.substring(0, 100)}...</p>
              </div>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}

export default Movie;