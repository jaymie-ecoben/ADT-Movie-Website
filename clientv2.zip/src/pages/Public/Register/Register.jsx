import { useState, useRef, useCallback } from 'react';
import './Register.css';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

function Register() {
  const [firstName, setFirstName] = useState('');
  const [middleName, setMiddleName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [password, setPassword] = useState('');
  const [isFieldsDirty, setIsFieldsDirty] = useState(false);
  const [isShowPassword, setIsShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [status, setStatus] = useState('idle');
  const [passwordHelp, setPasswordHelp] = useState(false);
  const emailRef = useRef();
  const passwordRef = useRef();
  const firstNameRef = useRef();
  const lastNameRef = useRef();
  const contactNumberRef = useRef();
  const navigate = useNavigate();

  // Show/hide password handler
  const handleShowPassword = useCallback(() => {
    setIsShowPassword((prev) => !prev);
  }, [isShowPassword]);

  // Password validation logic (simplified)
  const validatePassword = (password) => {
    const simplePassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{6,}$/;
    return simplePassword.test(password);
  };

  const handleOnChange = (event, type) => {
    setIsFieldsDirty(true);
    switch (type) {
      case 'firstName':
        setFirstName(event.target.value);
        break;
      case 'middleName':
        setMiddleName(event.target.value);
        break;
      case 'lastName':
        setLastName(event.target.value);
        break;
      case 'email':
        setEmail(event.target.value);
        break;
      case 'contactNumber':
        setContactNumber(event.target.value);
        break;
      case 'password':
        setPassword(event.target.value);
        if (!validatePassword(event.target.value)) {
          setPasswordHelp(true);
        } else {
          setPasswordHelp(false);
        }
        break;
      default:
        break;
    }
  };

  const handleRegister = async () => {
    const data = {
      firstName,
      middleName,
      lastName,
      email,
      contactNo: contactNumber, // Ensure this matches your server's expected key
      password,
    };
    setStatus('loading');
    setError('');
    setSuccessMessage('');

    try {
      const response = await axios.post('/admin/register', data, {
        headers: { 'Access-Control-Allow-Origin': '*' },
      });
      console.log(response);
      setSuccessMessage('Account successfully created!');
      setStatus('idle');
      setTimeout(() => {
        navigate('/main/movies');
      }, 2000); // Redirect after a short delay to show the success message
    } catch (e) {
      setError('Failed to create account. Please try again.');
      console.log(e);
      setStatus('idle');
    }
  };

  // Redirect to login page
  const goToLogin = () => {
    navigate('/login');
  };

  return (
    <div className='Register'>
      <div className='main-container'>
        <form>
          <div className='form-container'>
            <h1>Register</h1>
            {error && <span className='errors'>{error}</span>}
            {successMessage && <span className='success'>{successMessage}</span>}
            <div className='form-group'>
              <label>First Name:</label>
              <input
                type='text'
                name='first-name'
                ref={firstNameRef}
                onChange={(e) => handleOnChange(e, 'firstName')}
              />
            </div>
            <div className='form-group'>
              <label>Middle Name:</label>
              <input
                type='text'
                name='middle-name'
                onChange={(e) => handleOnChange(e, 'middleName')}
              />
            </div>
            <div className='form-group'>
              <label>Last Name:</label>
              <input
                type='text'
                name='last-name'
                ref={lastNameRef}
                onChange={(e) => handleOnChange(e, 'lastName')}
              />
            </div>
            <div className='form-group'>
              <label>Email:</label>
              <input
                type='email'
                name='email'
                ref={emailRef}
                onChange={(e) => handleOnChange(e, 'email')}
              />
            </div>
            <div className='form-group'>
              <label>Contact Number:</label>
              <input
                type='tel'
                name='contact-number'
                ref={contactNumberRef}
                onChange={(e) => handleOnChange(e, 'contactNumber')}
                pattern='[0-9]{10}'
              />
            </div>
            <div className='form-group'>
              <label>Password:</label>
              <input
                type={isShowPassword ? 'text' : 'password'}
                name='password'
                ref={passwordRef}
                onChange={(e) => handleOnChange(e, 'password')}
              />
              {passwordHelp && (
                <span className='errors'>
                  Password must be at least 6 characters long, include an uppercase letter, a lowercase letter, and a number.
                </span>
              )}
            </div>
            <div className='show-password' onClick={handleShowPassword}>
              {isShowPassword ? 'Hide' : 'Show'} Password
            </div>
            <div className='submit-container'>
              <button
                type='button'
                disabled={status === 'loading'}
                onClick={() => {
                  if (status === 'loading') {
                    return;
                  }
                  if (firstName && lastName && email && contactNumber && password && !passwordHelp) {
                    handleRegister();
                  } else {
                    setIsFieldsDirty(true);
                    if (firstName === '') {
                      firstNameRef.current.focus();
                    } else if (lastName === '') {
                      lastNameRef.current.focus();
                    } else if (email === '') {
                      emailRef.current.focus();
                    } else if (contactNumber === '') {
                      contactNumberRef.current.focus();
                    } else if (password === '') {
                      passwordRef.current.focus();
                    }
                  }
                }}
              >
                {status === 'idle' ? 'Register' : 'Loading'}
              </button>
            </div>
            <div className='register-container'>
              <p>
                <a href='/login'>Already have an account? Sign In</a>
              </p>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Register;
