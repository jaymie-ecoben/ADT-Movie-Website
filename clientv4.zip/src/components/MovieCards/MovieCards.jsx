import './MovieCards.css';

function MovieCards({ movie, onClick }) {
  return (
    <div className='card' onClick={onClick}>
      <img className='card__image' src={movie.posterPath} alt={`${movie.title} poster`} />
      <div className='card__overlay'>
        <h3 className='card__title'>{movie.title}</h3>
        <p className='card__description'>{movie.description}</p>
        <button className='card__button'>More Info</button>
      </div>
    </div>
  );
}

export default MovieCards;
