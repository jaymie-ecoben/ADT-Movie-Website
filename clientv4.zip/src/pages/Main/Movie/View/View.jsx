import React, { useEffect, useState, useMemo } from 'react';
import { useMovieContext } from '../../../../context/MovieContext';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import './View.css';

function View() {
  const { movie, setMovie } = useMovieContext();
  const { movieId } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchMovie = async () => {
      if (!movieId) {
        navigate('/');
        return;
      }

      setLoading(true);
      setError(null);

      try {
        const response = await axios.get(`/movies/${movieId}`);
        setMovie(response.data);
      } catch (err) {
        console.error('Failed to fetch movie:', err);
        setError(err);
        navigate('/');
      } finally {
        setLoading(false);
      }
    };

    fetchMovie();
    return () => setMovie(null);
  }, [movieId, navigate, setMovie]);

  const imageUrl = useMemo(() => {
    if (!movie) return '';
    return movie.poster_path 
      ? `https://image.tmdb.org/t/p/original${movie.poster_path}` 
      : '/placeholder-image.jpg';
  }, [movie]);

  const handleBack = () => {
    navigate('/', { replace: true });
  };

  if (loading) {
    return (
      <div className="loading">
        <div className="spinner"></div>
        <p>Loading movie details...</p>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="error-container">
        <h2>Oops! Something went wrong</h2>
        <p>Unable to load movie details. Please try again later.</p>
        <button onClick={handleBack} className="error-button">
          Return to Home
        </button>
      </div>
    );
  }

  return (
    <div className="view-container">
      <div 
        className="banner" 
        style={{ 
          backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url(${imageUrl})` 
        }}
      >
        <h1>{movie.title}</h1>
      </div>

      <button 
        className="back-button" 
        onClick={handleBack}
        aria-label="Go back"
      >
        ← Back
      </button>

      <div className="view-content">
        <section className="view-section overview">
          <h2>Overview</h2>
          <p>{movie.overview || 'No overview available.'}</p>
        </section>
      </div>
    </div>
  );
}

export default View;