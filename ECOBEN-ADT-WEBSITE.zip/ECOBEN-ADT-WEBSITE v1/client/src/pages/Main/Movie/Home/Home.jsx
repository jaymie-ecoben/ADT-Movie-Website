import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import MovieCards from '../../../../components/MovieCards/MovieCards';
import { useMovieContext } from '../../../../context/MovieContext';
import './Home.css';

const Home = () => {
  const navigate = useNavigate();
  const [featuredMovie, setFeaturedMovie] = useState(null);
  const [loading, setLoading] = useState(true);
  const { movieList, setMovieList, setMovie } = useMovieContext();

  const fetchMovies = useCallback(async () => {
    try {
      const response = await axios.get('/movies');
      const movies = response.data;
      setMovieList(movies);
      setFeaturedMovie(movies[Math.floor(Math.random() * movies.length)]);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch movies:', error);
      setLoading(false);
    }
  }, [setMovieList]);

  useEffect(() => {
    fetchMovies();
  }, [fetchMovies]);

  useEffect(() => {
    if (movieList.length) {
      const timer = setTimeout(() => {
        const random = Math.floor(Math.random() * movieList.length);
        setFeaturedMovie(movieList[random]);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [featuredMovie, movieList]);

  const handleMovieClick = useCallback((movie) => {
    navigate(`/view/${movie.id}`);
    setMovie(movie);
  }, [navigate, setMovie]);

  if (loading) {
    return <div className="loading-screen"></div>;
  }

  return (
    <div className="home-container">
      {featuredMovie && (
        <div 
          className="featured-movie"
          style={{backgroundImage: `url(${featuredMovie.backdropPath})`}}
        >
          <div className="featured-content">
            <h1>{featuredMovie.title}</h1>
            <div className="featured-actions">
              <button onClick={() => handleMovieClick(featuredMovie)}>
                Play
              </button>
              <button>More Info</button>
            </div>
          </div>
        </div>
      )}

      <div className="movie-row">
        <h2>Trending Now</h2>
        <div className="movie-grid">
          {movieList.map((movie) => (
            <MovieCards
              key={movie.id}
              movie={movie}
              onClick={() => handleMovieClick(movie)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Home;