import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './CastAndCrew.css';

function CastAndCrew() {
  const { movieId } = useParams();
  const navigate = useNavigate(); 
  const [cast, setCast] = useState([]);
  const [crew, setCrew] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (movieId) {
      fetchCastAndCrew(movieId);
    }
  }, [movieId]);

  const fetchCastAndCrew = async (movieId) => {
    try {
      const response = await axios.get(`http://localhost/movieproject-api/casts/${movieId}`);
      setCast(response.data || []);
      const crewResponse = await axios.get(`http://localhost/movieproject-api/crew/${movieId}`);
      setCrew(crewResponse.data || []);
    } catch (error) {
      console.error('Error fetching cast and crew:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="cast-and-crew-container">
      <button className="back-button" onClick={() => navigate(-1)}>Back</button>
      {loading ? (
        <p>Loading cast and crew...</p>
      ) : (
        <>
          <div className="cast-container">
            <h2>Cast</h2>
            <div className="cast-grid">
              {cast.map((member) => (
                <div key={member.id} className="cast-member">
                  <img
                    src={member.profile_path ? `https://image.tmdb.org/t/p/w185${member.profile_path}` : 'https://via.placeholder.com/150'}
                    alt={member.name}
                  />
                  <p className="cast-name">{member.name}</p>
                  <p className="cast-character">as {member.character}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="crew-container">
            <h2>Crew</h2>
            <div className="crew-list">
              {crew.map((member) => (
                <div key={member.id} className="crew-member">
                  <p className="crew-name">{member.name}</p>
                  <p className="crew-role">{member.job}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default CastAndCrew;
